package com.foodie.foodie_backend.Controller;

import com.foodie.foodie_backend.Security.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProtectedController {

    private final JwtUtil jwtUtil;

    // Inject JwtUtil to validate JWT tokens
    public ProtectedController(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @GetMapping("/protected-route")
    public ResponseEntity<?> getProtectedData(@RequestHeader("Authorization") String token) {
        // Validate the token and extract the claims
        if (token != null && token.startsWith("Bearer ")) {
            token = token.substring(7);  // Remove "Bearer " prefix

            // Use JwtUtil class to validate and extract data from the token
            if (jwtUtil.validateToken(token)) {
                String email = jwtUtil.extractEmail(token);
                // Fetch protected data for the authenticated user
                return ResponseEntity.ok(new Message("Protected data for " + email));
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token");
            }
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authorization token is missing");
        }
    }

    // Message class to return in response
    public static class Message {
        private String message;

        public Message(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
