package com.foodie.foodie_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodieBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodieBackendApplication.class, args);
	}

}
	